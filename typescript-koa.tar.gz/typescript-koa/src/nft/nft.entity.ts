import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export default class NFT {

  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column()
  description: string;

  @Column()
  properties: json;

  @Column()
  minted: bool;

  @Column()
  contract_address: string;

  @Column()
  token_id: string;

  @Column()
  token_standard: string;

  @Column()
  chain string;

  @Column({nullable: true})
  ipfs_uri: string;

  @Column({nullable: true})
  mint_time: timestamp;

  @Column()
  owner_address: string;
}
